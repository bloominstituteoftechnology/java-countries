DELETE
FROM employees;

INSERT INTO employees(empid, fname, lname, salary)
    VALUES (1, 'Steve', 'Green', 45000),
           (2, 'Liu', 'Wong', 50000),
           (3, 'Ana', 'Trujillo', 75000);

alter sequence hibernate_sequence restart with 5;