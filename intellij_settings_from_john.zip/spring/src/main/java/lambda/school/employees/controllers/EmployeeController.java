package lambda.school.employees.controllers;

import lambda.school.employees.models.Employee;
import lambda.school.employees.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping(value = "/employees/all", produces = "application/json")
    public ResponseEntity<?> findAllEmployees() {
        List<Employee> employees = new ArrayList<>();

        employeeRepository.findAll().iterator().forEachRemaining(e -> employees.add(e));

        return new ResponseEntity<>(employees, HttpStatus.OK);
    }

    // http://localhost:2019/employees/total
    @GetMapping(value = "/employees/total", produces = "application/json")
    public ResponseEntity<?> getTotal() {
        List<Employee> employeeList = new ArrayList<>();
        employeeRepository.findAll().iterator().forEachRemaining(employeeList::add);

        double total = 0.0;
        for (Employee e : employeeList) {
            total += e.getSalary();
        }

        System.out.println("The total is: " + total);

        return new ResponseEntity<>(total, HttpStatus.OK);
    }


    // http://localhost:2019/employees/name/{letter}
    @GetMapping(value = "/employees/name/{letter}", produces = "application/json")
    public ResponseEntity<?> findByName(@PathVariable char letter) {
        List<Employee> employeeList = new ArrayList<>();
        employeeRepository.findAll().iterator().forEachRemaining(employeeList::add);

        List<Employee> filteredList = filterEmployees(employeeList,
            (e) ->e.getFname().charAt(0) == letter);

        return new ResponseEntity<>(filteredList, HttpStatus.OK);
    }

    private List<Employee> filterEmployees(List<Employee> employeeList, CheckEmployees tester) {
        List<Employee> rtnList = new ArrayList<>();

        for(Employee e : employeeList) {
            if (tester.test(e)) {
                rtnList.add(e);
            }
        }

        return rtnList;
    }
}
